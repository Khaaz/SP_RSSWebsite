<?php

// liste des modules � inclure

$dConfig['includes']=array('Validation.php');

//BD

$base="";
$login="";
$mdp="";

//Vues
$vues['erreur']=array('url'=>'erreur.php');
$vues['vuephp1']=array('url'=>'vuephp1.php');

//Controllers
$cont['contuser']=array('url'=>'Controleur.php');
