<?php

class Simplemodel
{

//constructeur
//vide


function get_data() : string
{
return "Mon modèle ne fait rien";
}

//fin modeles
}
?> 