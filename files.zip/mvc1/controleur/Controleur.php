<?php

//chargement biblio
require_once(__DIR__.'/Validation.php');
require_once(__DIR__.'/../modeles/Simplemodel.php');


//chargement config
include_once(__DIR__.'/../config/Config.php');

//debut

//on initialise un tableau d'erreur
$dataVueErreur = array ();

try{
$action=$_REQUEST['action'];

switch($action) {

//pas d'action, on réinitialise 1er appel
case NULL:
	Reinit();
	break;


case "validationFormulaire":
	ValidationFormulaire();
	break;

//mauvaise action
default:
$dataVueErreur[] =	"Erreur d'appel php";
require (__DIR__.'/../vues/vuephp1.php');
break;
}

} catch (PDOException $e)
{
	//si erreur BD, pas le cas ici
	$dataVueErreur[] =	"Erreur inattendue!!! ";
	require (__DIR__.'/../vues/erreur.php');

}
catch (Exception $e2)
	{
	$dataVueErreur[] =	"Erreur inattendue!!! ";
	require (__DIR__.'/../vues/erreur.php');
	}


//fin
exit(0);


function Reinit()  {
$dataVue = array (
	'nom' => "",
	'age' => 0,
	);
	require (__DIR__.'/../vues/vuephp1.php');
}

function ValidationFormulaire() {
	global $dataVueErreur;// nécessaire pour utiliser variables globales

	$nom=$_REQUEST['txtNom']; // txtNom = nom du champ texte dans le formulaire
	$age=$_REQUEST['txtAge'];
	Validation::val_form($nom,$age,$dataVueErreur);
	$model = new Simplemodel();
	$data=$model->get_data();

$dataVue = array (
	'nom' => $nom,
	'age' => $age,
        'data' => $data,
	);
	require (__DIR__.'/../vues/vuephp1.php');
}

?>
