<?php
//si controller pas objet
  header('Location: controleur/Controleur.php');
?>